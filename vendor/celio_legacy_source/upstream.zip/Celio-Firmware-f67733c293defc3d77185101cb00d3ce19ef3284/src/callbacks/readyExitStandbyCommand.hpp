#include <zephyr/kernel.h>
#include "TransiveStruct.hpp"

TransiveStruct readyExitStandbyCommand();